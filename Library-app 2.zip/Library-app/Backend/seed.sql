-- === Users ===
INSERT INTO users (name, email, password, role) VALUES
('Admin', 'admin@library.com', 'admin123', 'admin'),
('Tester One', 'tester1@library.com', 'test123', 'user'),
('Tester Two', 'tester2@library.com', 'test123', 'user');

-- === Books ===
INSERT INTO books (title, author, category, quantity, created_at) VALUES
('The Go Programming Language', 'Alan A. A. Donovan', 'Programming', 5, NOW()),
('Clean Code', 'Robert C. Martin', 'Software Engineering', 7, NOW()),
('Designing Data-Intensive Applications', 'Martin Kleppmann', 'Databases', 6, NOW()),
('Docker Deep Dive', 'Nigel Poulton', 'DevOps', 8, NOW()),
('Kubernetes Up & Running', 'Brendan Burns', 'DevOps', 10, NOW()),
('Introduction to Algorithms', 'Thomas H. Cormen', 'Algorithms', 4, NOW()),
('The Pragmatic Programmer', 'Andrew Hunt', 'Software Engineering', 9, NOW()),
('Microservices with Go', 'Nic Jackson', 'Programming', 5, NOW()),
('Building Microservices', 'Sam Newman', 'Architecture', 7, NOW()),
('System Design Interview', 'Alex Xu', 'Architecture', 6, NOW());
