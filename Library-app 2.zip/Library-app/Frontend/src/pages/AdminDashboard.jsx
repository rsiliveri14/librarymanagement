import React, { useEffect, useState } from "react";
import API from "../api";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
  Legend,
} from "recharts";

export default function AdminDashboard() {
  const token = localStorage.getItem("token");
  const headers = { Authorization: token };
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchStats = async () => {
    try {
      const res = await API.get("/admin/stats", { headers });
      setStats(res.data.totals);
    } catch (err) {
      console.error("Error fetching admin stats:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();

    // Auto-refresh when library state changes
    const refreshHandler = () => fetchStats();
    window.addEventListener("libraryUpdate", refreshHandler);

    return () => window.removeEventListener("libraryUpdate", refreshHandler);
  }, []);

  if (loading) return <p>Loading dashboard...</p>;
  if (!stats) return <p>Failed to load admin stats.</p>;

  const chartData = [
    { name: "Total Users", value: stats.users },
    { name: "Total Book Titles", value: stats.books },
    { name: "Total Copies", value: stats.total_copies },
    { name: "Checkouts", value: stats.checkouts },
    { name: "Returns", value: stats.returns },
    { name: "Currently Borrowed", value: stats.currently_borrowed },
  ];

  return (
    <div style={{ padding: "20px" }}>
      <h2 style={{ textAlign: "center", marginBottom: "20px" }}>📊 Admin Dashboard</h2>

      {/* Summary cards */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
          gap: "20px",
          marginBottom: "40px",
        }}
      >
        <Card title="👥 Total Users" value={stats.users} />
        <Card title="📚 Total Book Titles" value={stats.books} />
        <Card title="📦 Total Copies in Library" value={stats.total_copies} />
        <Card title="✅ Total Checkouts" value={stats.checkouts} />
        <Card title="↩️ Total Returns" value={stats.returns} />
        <Card title="📖 Currently Borrowed" value={stats.currently_borrowed} />
      </div>

      {/* Chart */}
      <div
        style={{
          background: "#fff",
          padding: "20px",
          borderRadius: "12px",
          boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
        }}
      >
        <h3 style={{ textAlign: "center", marginBottom: "10px" }}>📈 Library Overview</h3>
        <ResponsiveContainer width="100%" height={320}>
          <BarChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="value" fill="#007bff" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

// ---------- CARD COMPONENT ----------
function Card({ title, value }) {
  return (
    <div
      style={{
        background: "#fff",
        padding: "20px",
        borderRadius: "10px",
        boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
        textAlign: "center",
      }}
    >
      <h4 style={{ color: "#555", marginBottom: "10px" }}>{title}</h4>
      <p style={{ fontSize: "24px", fontWeight: "bold", color: "#007bff" }}>{value}</p>
    </div>
  );
}
