import React, { useEffect, useState } from "react";
import API from "../api";

export default function Cart() {
  const token = localStorage.getItem("token");
  const headers = { Authorization: token };
  const [cart, setCart] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchCart = async () => {
    try {
      const res = await API.get("/cart", { headers });
      setCart(res.data);
    } catch (err) {
      console.error("Failed to load cart:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCart();
  }, []);

  // ---- Increase Quantity ----
  const increaseQuantity = async (bookID) => {
    try {
      await API.post(`/cart/add/${bookID}`, {}, { headers });
      fetchCart();
    } catch (err) {
      console.error("Failed to increase quantity:", err);
      alert("Error increasing quantity or book out of stock.");
    }
  };

  // ---- Decrease Quantity ----
  const decreaseQuantity = async (bookID) => {
    try {
      await API.post(`/cart/decrease/${bookID}`, {}, { headers });
      fetchCart();
    } catch (err) {
      console.error("Failed to decrease quantity:", err);
      alert("Error decreasing quantity.");
    }
  };

  // ---- Remove Item ----
  const removeItem = async (bookID) => {
    if (!window.confirm("Remove this book from your cart?")) return;
    try {
      await API.delete(`/cart/delete/${bookID}`, { headers });
      fetchCart();
    } catch (err) {
      console.error("Failed to delete item:", err);
      alert("Error removing item.");
    }
  };

  // ---- Checkout ----
  const handleCheckout = async () => {
    if (!cart.length) {
      alert("Your cart is empty!");
      return;
    }
    if (!window.confirm("Proceed to checkout?")) return;

    try {
      await API.post("/cart/checkout", {}, { headers });
      alert("Checkout successful!");
      window.dispatchEvent(new Event("libraryUpdate")); // 🔹 Triggers admin dashboard & profile update
      fetchCart();
    } catch (err) {
      console.error("Checkout failed:", err);
      alert("Error during checkout. Try again.");
    }
  };

  if (loading) return <p>Loading cart...</p>;
  if (!cart.length)
    return (
      <div style={{ textAlign: "center", marginTop: "50px" }}>
        <h3>Your cart is empty.</h3>
      </div>
    );

  return (
    <div style={{ padding: "20px" }}>
      <h2 style={{ textAlign: "center", marginBottom: "20px" }}>🛒 My Cart</h2>

      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          background: "#fff",
          boxShadow: "0 2px 5px rgba(0,0,0,0.1)",
        }}
      >
        <thead style={{ background: "#f0f0f0" }}>
          <tr>
            <th style={th}>Title</th>
            <th style={th}>Author</th>
            <th style={th}>Quantity</th>
            <th style={th}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {cart.map((item) => (
            <tr key={item.id} style={{ borderBottom: "1px solid #eee" }}>
              <td style={td}>{item.book?.title}</td>
              <td style={td}>{item.book?.author}</td>
              <td style={{ textAlign: "center", padding: "10px" }}>
                {item.quantity}
              </td>
              <td style={{ textAlign: "center", padding: "10px" }}>
                <button
                  onClick={() => increaseQuantity(item.book.id)}
                  style={btnGreen}
                >
                  +
                </button>
                <button
                  onClick={() => decreaseQuantity(item.book.id)}
                  style={btnYellow}
                  disabled={item.quantity <= 1}
                >
                  −
                </button>
                <button
                  onClick={() => removeItem(item.book.id)}
                  style={btnRed}
                >
                  Remove
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div style={{ textAlign: "center", marginTop: "25px" }}>
        <button onClick={handleCheckout} style={btnBlue}>
          ✅ Checkout
        </button>
      </div>
    </div>
  );
}

// ---------- Styles ----------
const th = { textAlign: "center", padding: "10px" };
const td = { padding: "10px" };

const btnGreen = {
  backgroundColor: "#28a745",
  color: "white",
  border: "none",
  padding: "5px 10px",
  marginRight: "5px",
  borderRadius: "4px",
  cursor: "pointer",
};

const btnYellow = {
  backgroundColor: "#ffc107",
  color: "black",
  border: "none",
  padding: "5px 10px",
  marginRight: "5px",
  borderRadius: "4px",
  cursor: "pointer",
};

const btnRed = {
  backgroundColor: "#dc3545",
  color: "white",
  border: "none",
  padding: "5px 10px",
  borderRadius: "4px",
  cursor: "pointer",
};

const btnBlue = {
  backgroundColor: "#007bff",
  color: "white",
  border: "none",
  padding: "10px 20px",
  borderRadius: "6px",
  cursor: "pointer",
  fontWeight: 600,
};
